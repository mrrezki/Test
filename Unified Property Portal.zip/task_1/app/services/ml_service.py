"""Machine Learning Service module."""
import joblib
import json
import os
import pandas as pd
from typing import List, Dict, Any
from app.core.config import settings

class MLService:
    """Service to handle the ML model loading and predictions."""
    
    def __init__(self):
        """Initialize empty model and metrics."""
        self.model = None
        self.metrics = None
        
    def load_artifacts(self) -> None:
        """Loads the Scikit-Learn model and metadata from disk to memory."""
        if os.path.exists(settings.MODEL_PATH):
            self.model = joblib.load(settings.MODEL_PATH)
        else:
            print(f"Warning: Model file not found at {settings.MODEL_PATH}")
            
        if os.path.exists(settings.METRICS_PATH):
            with open(settings.METRICS_PATH, "r") as f:
                self.metrics = json.load(f)

    def is_loaded(self) -> bool:
        """
        Checks if the model has been loaded successfully.
        
        Returns:
            bool: True if loaded, False otherwise.
        """
        return self.model is not None

    def predict(self, features_list: List[Dict[str, Any]]) -> List[float]:
        """
        Computes predictions for a batch of housing features.
        
        Args:
            features_list (List[Dict[str, Any]]): The input batch to predict on.
            
        Returns:
            List[float]: The batch predictions.
            
        Raises:
            RuntimeError: If model is not loaded.
            ValueError: If missing input columns.
        """
        if not self.is_loaded():
            raise RuntimeError("Model is not loaded")
        
        df = pd.DataFrame(features_list)
        features_cols = [
            'square_footage', 'bedrooms', 'bathrooms', 'year_built', 
            'lot_size', 'distance_to_city_center', 'school_rating'
        ]
        
        # Verify columns exist
        for col in features_cols:
             if col not in df.columns:
                  raise ValueError(f"Missing required feature column: {col}")
                  
        X = df[features_cols]
        preds = self.model.predict(X)
        return preds.tolist()

    def get_metrics(self) -> dict:
        """
        Retrieves the model metrics.
        
        Returns:
            dict: The metrics dictionary.
            
        Raises:
            RuntimeError: If metrics are not loaded.
        """
        if self.metrics is None:
            raise RuntimeError("Metrics are not loaded")
        return self.metrics

# Singleton instance
ml_service_instance = MLService()

def get_ml_service() -> MLService:
    """
    FastAPI dependency yielding the singleton MLService.
    
    Returns:
        MLService: The global instance.
    """
    return ml_service_instance
