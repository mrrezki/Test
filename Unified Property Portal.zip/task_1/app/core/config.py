from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Housing Price Prediction API"
    MODEL_PATH: str = "model/model.joblib"
    METRICS_PATH: str = "model/metrics.json"

    class Config:
        env_file = ".env"

settings = Settings()
