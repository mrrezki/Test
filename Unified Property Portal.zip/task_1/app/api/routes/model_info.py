"""Model metadata API Controller."""
from fastapi import APIRouter, HTTPException, Depends
from app.services.ml_service import MLService, get_ml_service

router = APIRouter()

class ModelInfoController:
    """Class-based controller for retrieving ML model metrics."""
    
    def __init__(self, ml_service: MLService = Depends(get_ml_service)):
        """Initialize with MLService dependency."""
        self.ml_service = ml_service
        
    def retrieve_info(self) -> dict:
        """
        Fetches the saved ML coefficients and evaluation metrics.
        
        Returns:
            dict: Model information.
        """
        try:
            return self.ml_service.get_metrics()
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e))

@router.get("/model-info", tags=["model"])
def model_info_endpoint(controller: ModelInfoController = Depends()):
    """
    Endpoint to fetch ML model details and metrics.
    """
    return controller.retrieve_info()
