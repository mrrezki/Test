"""Prediction API Controller."""
from fastapi import APIRouter, HTTPException, Depends
from app.models.predict import PredictRequest, PredictResponse
from app.services.ml_service import MLService, get_ml_service

router = APIRouter()

class PredictController:
    """Class-based controller for prediction routes."""
    
    def __init__(self, ml_service: MLService = Depends(get_ml_service)):
        """Initialize controller with injected dependencies."""
        self.ml_service = ml_service

    def execute_prediction(self, request: PredictRequest) -> PredictResponse:
        """
        Handles the prediction request, computes the output using the ML service.
        
        Args:
            request (PredictRequest): The batch of features for prediction.
            
        Returns:
            PredictResponse: The batch of predictions.
        """
        try:
            # Prepare data
            data = [house.model_dump() if hasattr(house, 'model_dump') else house.dict() for house in request.features]
            
            # Predict
            predictions = self.ml_service.predict(data)
            
            return PredictResponse(predictions=predictions)
            
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except ValueError as e:
             raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error executing prediction: {str(e)}")

@router.post("/predict", response_model=PredictResponse, tags=["prediction"])
def predict_endpoint(request: PredictRequest, controller: PredictController = Depends()):
    """
    Endpoint to receive a prediction request and route it to the PredictController.
    """
    return controller.execute_prediction(request)
