"""System Health API Controller."""
from fastapi import APIRouter, Depends
from app.services.ml_service import MLService, get_ml_service

router = APIRouter()

class HealthController:
    """Class-based controller for health status."""
    
    def __init__(self, ml_service: MLService = Depends(get_ml_service)):
        """Initialize with MLService dependency."""
        self.ml_service = ml_service
        
    def check_health(self) -> dict:
        """
        Retrieves the system health and model verification status.
        
        Returns:
            dict: Status payload.
        """
        return {"status": "healthy", "model_loaded": self.ml_service.is_loaded()}

@router.get("/health", tags=["system"])
def health_endpoint(controller: HealthController = Depends()):
    """
    Endpoint to retrieve system health.
    """
    return controller.check_health()
