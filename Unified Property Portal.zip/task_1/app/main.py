"""Main application entrypoint."""
from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from app.api.router import api_router
from app.core.config import settings
from app.services.ml_service import ml_service_instance

app = FastAPI(title=settings.PROJECT_NAME)

@app.on_event("startup")
def startup_event():
    """Application startup event handler."""
    ml_service_instance.load_artifacts()

@app.get("/", include_in_schema=False)
def docs_redirect():
    """Redirect root path to the Swagger documentation."""
    return RedirectResponse(url="/docs")

app.include_router(api_router)
