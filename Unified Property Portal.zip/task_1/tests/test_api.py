"""Tests for the API endpoints."""

def test_health_check(client):
    """Test the /health endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "model_loaded": True}

def test_model_info(client):
    """Test the /model-info endpoint."""
    response = client.get("/model-info")
    assert response.status_code == 200
    assert "mock_r2" in response.json()

def test_predict(client):
    """Test the /predict endpoint and database record logging."""
    payload = {
        "features": [
            {
                "square_footage": 2000,
                "bedrooms": 3,
                "bathrooms": 2.5,
                "year_built": 1990,
                "lot_size": 5000,
                "distance_to_city_center": 10.2,
                "school_rating": 8.5
            }
        ]
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "predictions" in data
    assert len(data["predictions"]) == 1
    assert data["predictions"][0] == 300000.0
