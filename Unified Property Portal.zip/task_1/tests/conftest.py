"""Pytest fixtures and configuration."""
import pytest
from fastapi.testclient import TestClient

from app.main import app

@pytest.fixture(scope="module")
def client():
    # We mock the ML service output for predictable testing without actual model.joblib loaded
    from app.services.ml_service import MLService, get_ml_service
    class MockMLService(MLService):
        def is_loaded(self): return True
        def get_metrics(self): return {"mock_r2": 0.99}
        def predict(self, features): return [300000.0] * len(features)
        
    app.dependency_overrides[get_ml_service] = lambda: MockMLService()
    
    with TestClient(app) as client:
        yield client
