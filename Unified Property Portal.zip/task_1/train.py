import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import joblib
import json
import os

# Create model directory
os.makedirs('model', exist_ok=True)

# Load data
df = pd.read_csv('House Price Dataset.csv')

features = ['square_footage', 'bedrooms', 'bathrooms', 'year_built', 'lot_size', 'distance_to_city_center', 'school_rating']
X = df[features]
y = df['price']

# Train model
model = LinearRegression()
model.fit(X, y)

# Predictions
y_pred = model.predict(X)
r2 = r2_score(y, y_pred)

# Save model
joblib.dump(model, 'model/model.joblib')

# Save metrics
metrics = {
    'intercept': float(model.intercept_),
    'coefficients': {str(feat): float(coef) for feat, coef in zip(features, model.coef_)},
    'r2_score': float(r2)
}

with open('model/metrics.json', 'w') as f:
    json.dump(metrics, f, indent=4)

print("Model training complete. Model and metrics saved to model/ directory.")
