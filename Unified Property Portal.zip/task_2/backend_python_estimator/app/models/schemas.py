"""Pydantic schemas for data validation."""
from pydantic import BaseModel, Field

class PropertyDetails(BaseModel):
    """Schema representing property details requested for estimation."""
    square_footage: float = Field(..., gt=0, description="Size of the property in square feet")
    bedrooms: int = Field(..., gt=0, description="Total number of bedrooms")
    bathrooms: float = Field(..., gt=0, description="Total number of bathrooms")
    year_built: int = Field(..., gt=1800, le=2030, description="Year the property was constructed")
    lot_size: float = Field(..., gt=0, description="Total lot size in square feet")
    distance_to_city_center: float = Field(..., ge=0, description="Distance to city center in miles")
    school_rating: float = Field(..., ge=0, le=10, description="Average rating of local schools 0-10")

class EstimationResponse(BaseModel):
    """Schema representing the generated estimation result."""
    original_input: PropertyDetails
    estimated_price_usd: float
    confidence_interval_low: float
    confidence_interval_high: float
