"""API Routing for Estimator."""
from fastapi import APIRouter, Depends
from app.models.schemas import PropertyDetails, EstimationResponse
from app.services.estimation import EstimationService

api_router = APIRouter()

def get_estimation_service():
    return EstimationService()

class EstimatorController:
    """Class-Based View Controller for route definitions."""
    
    def __init__(self, service: EstimationService = Depends(get_estimation_service)):
        self.service = service
        
    async def calculate(self, req: PropertyDetails) -> EstimationResponse:
        """Calculates value of property mapping to EstimationResponse"""
        estimated_price = await self.service.request_estimate(req)
        
        # Adding some generic variance for visualization purposes logically derived from the prediction
        return EstimationResponse(
            original_input=req,
            estimated_price_usd=round(estimated_price, 2),
            confidence_interval_low=round(estimated_price * 0.92, 2),
            confidence_interval_high=round(estimated_price * 1.08, 2)
        )

@api_router.post("/estimate", response_model=EstimationResponse, tags=["Estimator"])
async def handle_estimate(req: PropertyDetails, controller: EstimatorController = Depends()):
    """
    Endpoint mapping property estimations locally.
    """
    return await controller.calculate(req)
