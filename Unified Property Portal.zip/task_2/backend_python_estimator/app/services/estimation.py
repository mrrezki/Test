import os
import httpx
from fastapi import HTTPException
from app.models.schemas import PropertyDetails

TASK1_URL = os.getenv("TASK1_ML_URL", "http://localhost:8000/predict")

class EstimationService:
    """Service handling third-party ML orchestration via httpx."""
    
    async def request_estimate(self, property_details: PropertyDetails) -> float:
        """
        Sends the property to the primary Task1 ML container and retrieves the price.
        
        Args:
            property_details (PropertyDetails): The housing metrics.
            
        Returns:
            float: Evaluated price.
        """
        payload = {
            "features": [property_details.model_dump()]
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(TASK1_URL, json=payload, timeout=10.0)
                response.raise_for_status()
                data = response.json()
                return data["predictions"][0]
            except httpx.HTTPError as exc:
                raise HTTPException(status_code=502, detail=f"Failed to communicate with Task 1 ML API: {str(exc)}")
            except (KeyError, IndexError):
                raise HTTPException(status_code=500, detail="Unexpected response schema from ML API.")
