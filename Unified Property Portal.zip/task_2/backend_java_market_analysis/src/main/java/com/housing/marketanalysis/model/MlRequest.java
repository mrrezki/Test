package com.housing.marketanalysis.model;

import lombok.Data;
import java.util.List;

/**
 * Wrapper for machine learning task API request body.
 */
@Data
public class MlRequest {
    private List<PropertyFeatures> features;
}
