package com.housing.marketanalysis.model;

import lombok.Data;

/**
 * Data Transfer Object representing housing properties.
 */
@Data
public class PropertyFeatures {
    private double square_footage;
    private int bedrooms;
    private double bathrooms;
    private int year_built;
    private double lot_size;
    private double distance_to_city_center;
    private double school_rating;
}
