package com.housing.marketanalysis.service;

import com.housing.marketanalysis.model.MlRequest;
import com.housing.marketanalysis.model.MlResponse;
import com.housing.marketanalysis.model.PropertyFeatures;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

/**
 * Service to orchestrate what-if analysis calls to the Python ML infrastructure.
 */
@Service
public class WhatIfService {

    @Value("${ml.task1.url}")
    private String task1Url;

    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * Executes a what-if prediction using the ML model.
     * @param features User modified property parameters
     * @return predicted evaluation price
     */
    public Double runSimulation(PropertyFeatures features) {
        MlRequest request = new MlRequest();
        request.setFeatures(Collections.singletonList(features));

        MlResponse response = restTemplate.postForObject(task1Url, request, MlResponse.class);

        if (response != null && response.getPredictions() != null && !response.getPredictions().isEmpty()) {
            return response.getPredictions().get(0);
        }
        throw new RuntimeException("Failed to retrieve prediction from ML container");
    }
}
