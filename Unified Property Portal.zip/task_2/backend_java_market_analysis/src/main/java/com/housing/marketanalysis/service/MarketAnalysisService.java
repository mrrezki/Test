package com.housing.marketanalysis.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Service responsible for aggregating general dataset statistics.
 */
@Service
public class MarketAnalysisService {

    /**
     * Returns cached mock aggregates imitating a large dataset scan.
     * @return Aggregate dataset metrics
     */
    @Cacheable("marketStats")
    public Map<String, Object> getMarketAggregates() {
        // Simulating heavy I/O aggregate scan
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("averagePrice", 265000.0);
        stats.put("totalListings", 50);
        stats.put("averageSquareFootage", 1650.0);
        stats.put("mostPopularZipCode", "90210");
        return stats;
    }
    
    /**
     * Generates a CSV formatted string of the aggregated stats
     */
    public String exportStatsAsCsv() {
        Map<String, Object> stats = getMarketAggregates();
        StringBuilder csv = new StringBuilder();
        csv.append("Metric,Value\n");
        stats.forEach((key, value) -> csv.append(key).append(",").append(value).append("\n"));
        return csv.toString();
    }
}
