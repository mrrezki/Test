package com.housing.marketanalysis.model;

import lombok.Data;
import java.util.List;

/**
 * Wrapper for machine learning task API response body.
 */
@Data
public class MlResponse {
    private List<Double> predictions;
}
