package com.housing.marketanalysis.controller;

import com.housing.marketanalysis.model.PropertyFeatures;
import com.housing.marketanalysis.service.MarketAnalysisService;
import com.housing.marketanalysis.service.WhatIfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST API Endpoints mapping market analytics and what-if routing.
 */
@RestController
@RequestMapping("/api/market")
@CrossOrigin(origins = "http://localhost:3000") // Enable Next.js Portal access
public class MarketAnalysisController {

    private final MarketAnalysisService analysisService;
    private final WhatIfService whatIfService;

    @Autowired
    public MarketAnalysisController(MarketAnalysisService analysisService, WhatIfService whatIfService) {
        this.analysisService = analysisService;
        this.whatIfService = whatIfService;
    }

    /**
     * Get aggregate cached statistics.
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStats() {
        return ResponseEntity.ok(analysisService.getMarketAggregates());
    }

    /**
     * Export market properties aggregate as direct CSV blob
     */
    @GetMapping("/export/csv")
    public ResponseEntity<String> exportCsv() {
        String csvData = analysisService.exportStatsAsCsv();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"market_analysis.csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csvData);
    }

    /**
     * Executes the 'what-if' tool prediction via Task 1 infrastructure 
     */
    @PostMapping("/what-if")
    public ResponseEntity<Map<String, Double>> executeWhatIf(@RequestBody PropertyFeatures features) {
        Double prediction = whatIfService.runSimulation(features);
        return ResponseEntity.ok(Map.of("simulated_price", prediction));
    }
}
