# Property Market Analysis Backend (Java)

This is the Java REST backend responsible for computing heavy data caching configurations and running simulation analysis requests. It serves as "App 2" in the ecosystem.

## Technical Details
- **Architecture**: Spring Boot 3.4.4
- **Runtime**: Java OpenJDK 21
- **API Scope**: Local Port `8080`

## Containerization
This application runs implicitly through Docker so you do not need to install Java natively. It uses a multi-stage `maven:3.9-eclipse-temurin-21` compiler and deploys onto a lightweight `eclipse-temurin:21-jre` runtime.

## Running Tests & Execution

1. Build the lightweight image:
   ```bash
   docker build -t task2_java_backend .
   ```

2. Run the application bound to port 8080:
   ```bash
   docker run -p 8080:8080 task2_java_backend
   ```
   *Note: Because this queries Task 1 locally using `localhost:8000`, depending on your Docker configuration, you may need to use `host` networking or `http://host.docker.internal:8000/predict`.*
