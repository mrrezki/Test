# Multi-Application Next.js Portal (Task 2)

This directory contains the expanded architecture for connecting the core machine learning inference from Task 1 into two separate, full-stack workflow applications unified by a single Next.js hub.

To successfully run and demonstrate this cluster of microservices live during your interview, you will need to boot them up in the correct sequence.

## 🚀 System Access & Execution Guide

The ecosystem is made of **Four** distinct running applications. Ensure the ports available below are free on your system before proceeding.

for application run
use command -
\task_2>docker-compose up --build

---

### Step 1: Start the Task 1 Machine Learning API
This is the core ML regression service that both backend applications rely on.
* **Tech:** FastAPI + Docker
* **Path:** `d:\POC\task_1`
* **Port:** `8000`

**Command to Start:**
```bash
cd d:\POC\task_1
# (Optional) rebuild if you made changes: docker build -t task_1 .
docker run -p 8000:8000 task_1
```
*Wait for the application to output `Application startup complete.`*

---

### Step 2: Start the App 1 Backend (Python Property Estimator)
This backend validates form schemas and securely communicates with the local ML container.
* **Tech:** Python 3.12+ (FastAPI)
* **Path:** `d:\POC\task_2\backend_python_estimator`
* **Port:** `8001`
* **Access API Docs:** `http://localhost:8001/docs`

**Command to Start:**
```bash
cd d:\POC\task_2\backend_python_estimator
pip install -r requirements.txt
uvicorn app.main:app --port 8001
```

---

### Step 3: Start the App 2 Backend (Java Market Analytics)
This microservice loads the overarching market database, caching heavy aggregate statistical queries, and routes "What-if" simulations.
* **Tech:** Java 21, Spring Boot 3.4.4
* **Path:** `d:\POC\task_2\backend_java_market_analysis`
* **Port:** `8080`
* **Access API Docs:** `http://localhost:8080/swagger-ui.html` *(Assuming Swagger is built)*

**Command to Start (via Docker):**
```bash
cd d:\POC\task_2\backend_java_market_analysis
docker build -t task2_java_backend .
docker run -p 8080:8080 task2_java_backend
```

---

### Step 4: Start the Next.js Unified UI Portal
The unified interface that consumes both App 1 and App 2 APIs.
* **Tech:** Next.js (App Router), Tailwind CSS
* **Path:** `d:\POC\task_2\portal`
* **Port:** `3000`
* **Access Portal UI:** [http://localhost:3000](http://localhost:3000)

**Command to Start:**
```bash
cd d:\POC\task_2\portal
npm run dev
```

## 🌐 Overall Endpoints Access Overview
* **Primary Dashboard URL:** [http://localhost:3000](http://localhost:3000)
* **Python Orchestration Validation API:** [http://localhost:8001/docs](http://localhost:8001/docs)
* **Java Data Caching Analytics API:** [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)
* **Base Containerized ML Infrastructure:** [http://localhost:8000/docs](http://localhost:8000/docs)
