# Multi-Application Next.js Portal (Task 2)

This directory contains the unified Next.js dashboard responsible for displaying user interfaces and routing traffic to the corresponding Python and Java backend APIs.

## Architecture

* **Framework:** Next.js 15 (App Router)
* **Styling:** Tailwind CSS
* **Data Flow:** Uses React Server Components and Server Actions to securely proxy requests to the internal Docker network (`task2-python-estimator:8001` and `task2-java-analysis:8080`) avoiding browser CORS issues.

## Applications

1. **Property Value Estimator (`/estimator`)**
   - Connects to the **Python API** to run single property validations against the root ML Model.
2. **Market Analysis (`/analysis`)**
   - Connects to the **Java Spring Boot API** to visualize historical caches and "what-if" dataset analysis.

## Running the Application Locally (No Docker)

If you're running outside of the `docker-compose` orchestration, you can start the UI dynamically:

1. Copy the `.env.example` configurations to `.env.local`
2. Run standard Node commands:
```bash
npm install
npm run dev
```

The portal will be accessible at [http://localhost:3000](http://localhost:3000).
