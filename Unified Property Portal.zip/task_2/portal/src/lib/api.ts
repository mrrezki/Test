"use server";

// Fallbacks are set to localhost for when you run npm run dev locally. Docker compose passes the DNS natively
const PYTHON_API_URL = process.env.PYTHON_API_URL || "http://localhost:8001";
const JAVA_API_URL = process.env.JAVA_API_URL || "http://localhost:8080";

/**
 * Validates and tests property prices through the Python ML proxy.
 */
export async function fetchPropertyEstimate(payload: any) {
  try {
    const res = await fetch(`${PYTHON_API_URL}/estimate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      cache: 'no-store'
    });
    if (!res.ok) throw new Error("Failed to estimate property");
    return await res.json();
  } catch (error: any) {
    console.error(error);
    throw new Error(error.message);
  }
}

/**
 * Retrieves cached aggregations from the Java Backend.
 */
export async function fetchMarketStats() {
  try {
    const res = await fetch(`${JAVA_API_URL}/api/market/stats`, {
      cache: 'no-store' // typically you'd use next: { revalidate: 3600 } to leverage app router cache
    });
    if (!res.ok) throw new Error("Failed to grab statistical aggregates");
    return await res.json();
  } catch (error: any) {
    console.error(error);
    return null;
  }
}

/**
 * Runs a 'What-if' batch simulation against the Java Market backend.
 */
export async function runWhatIfSimulation(payload: any) {
  try {
    const res = await fetch(`${JAVA_API_URL}/api/market/what-if`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error("Simulation failed");
    return await res.json();
  } catch (error: any) {
    console.error(error);
    throw new Error(error.message);
  }
}
