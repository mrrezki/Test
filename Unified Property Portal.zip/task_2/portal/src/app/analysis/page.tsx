import React from "react";
import { fetchMarketStats } from "@/lib/api";

export default async function AnalysisPage() {
  const stats = await fetchMarketStats();

  return (
    <div className="space-y-8">
      <div className="border-b border-gray-200 pb-5">
        <h2 className="text-3xl font-bold leading-7 text-gray-900">Market Analytics Dashboard</h2>
        <p className="mt-2 text-sm text-gray-500">Retrieve aggregated big-data analytics sourced natively from Java Spring Boot.</p>
      </div>
      
      {stats ? (
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
            <div>
              <h3 className="text-lg leading-6 font-medium text-gray-900">Dataset Overview Metadata</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">Processed by Java Spring Boot backend infrastructure.</p>
            </div>
            <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs rounded-full font-semibold border border-emerald-200 shadow-sm">CACHED SERVER RENDERED</span>
          </div>
          <div className="border-t border-gray-200">
             <dl>
                {Object.entries(stats).map(([k, v], idx) => (
                   <div key={k} className={`${idx % 2 === 0 ? "bg-slate-50" : "bg-white"} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6 hover:bg-blue-50 transition-colors`}>
                      <dt className="text-sm font-medium text-slate-500 capitalize">{k.replace(/([A-Z])/g, ' $1').trim()}</dt>
                      <dd className="mt-1 text-sm text-slate-900 sm:mt-0 sm:col-span-2 font-mono font-semibold">{v as any}</dd>
                   </div>
                ))}
             </dl>
          </div>
          <div className="px-4 py-4 sm:px-6 bg-slate-50 border-t border-gray-200 flex justify-end">
              <button className="bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-md shadow text-sm font-medium transition-colors">
                 Export to CSV
              </button>
          </div>
        </div>
      ) : (
        <div className="text-center p-12 bg-red-50 text-red-600 rounded-lg shadow-inner">
           <h3 className="text-xl font-bold mb-2">Connection Refused</h3>
           <p>Failed to retrieve data from the Java cluster natively. Double check Docker Compose logs.</p>
        </div>
      )}
    </div>
  )
}
