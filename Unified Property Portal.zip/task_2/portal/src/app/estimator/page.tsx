"use client";
import React, { useState } from "react";
import { fetchPropertyEstimate } from "@/lib/api";

export default function EstimatorPage() {
  const [formData, setFormData] = useState({
    square_footage: 1500, bedrooms: 3, bathrooms: 2, year_built: 2000, lot_size: 5000, distance_to_city_center: 5, school_rating: 8
  });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({...formData, [e.target.name]: parseFloat(e.target.value)});
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError(""); setResult(null);
    try {
       const data = await fetchPropertyEstimate(formData);
       setResult(data);
    } catch(err: any) {
       setError(err.message || "Something went wrong communicating with the Python Proxy.");
    }
    setLoading(false);
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="border-b border-gray-200 pb-5">
        <h2 className="text-3xl font-bold leading-7 text-gray-900 sm:truncate sm:tracking-tight">Property Estimator</h2>
        <p className="mt-2 text-sm text-gray-500">Calculate exact valuations evaluated by the Python BFF proxy targeting the core Machine Learning engine.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow border border-slate-100 space-y-4">
           {Object.keys(formData).map(key => (
             <div key={key}>
                <label className="block text-sm font-medium text-gray-700 capitalize mb-1">{key.replace(/_/g, " ")}</label>
                <input type="number" step="any" name={key} value={(formData as any)[key]} onChange={handleChange} required className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-slate-50 px-4 py-2 border"/>
             </div>
           ))}
           <button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg shadow disabled:opacity-50 transition-all">
             {loading ? "Calculating..." : "Estimate Value"}
           </button>
        </form>

        <div className="flex flex-col">
           {error && <div className="bg-red-50 text-red-600 p-4 rounded-xl border border-red-200">{error}</div>}
           {result && (
              <div className="bg-gradient-to-br from-slate-900 to-blue-900 text-white p-8 rounded-2xl shadow-xl flex-grow flex flex-col justify-center items-center text-center hover:scale-105 transition-transform duration-300">
                 <h3 className="text-xl font-medium text-slate-300 mb-2">Estimated Value</h3>
                 <p className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-400 mb-6">
                    ${result.estimated_price_usd.toLocaleString()}
                 </p>
                 <div className="w-full bg-slate-800 rounded-lg p-4 grid grid-cols-2">
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-widest">Lower Bound</p>
                      <p className="font-semibold text-lg text-red-300">${result.confidence_interval_low.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-widest">Upper Bound</p>
                      <p className="font-semibold text-lg text-emerald-300">${result.confidence_interval_high.toLocaleString()}</p>
                    </div>
                 </div>
              </div>
           )}
        </div>
      </div>
    </div>
  )
}
