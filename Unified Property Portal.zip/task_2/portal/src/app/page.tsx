import Link from "next/link";
import { fetchMarketStats } from "@/lib/api";

export default async function Home() {
  // Use a secure Server Component React hook to load Java generic stats via server
  const stats = await fetchMarketStats();

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-extrabold text-slate-900 tracking-tight">
          Welcome to the <span className="text-blue-600">Unified Analytics Portal</span>
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-slate-600">
          Seamlessly predicting market fluctuations using multi-backend architecture powered by state-of-the-art machine learning algorithms.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-5xl">
        <Link href="/estimator" className="group">
          <div className="h-full bg-white rounded-2xl shadow-sm border border-slate-200 p-8 hover:shadow-lg transition-all hover:border-blue-300">
            <div className="h-12 w-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
               <span className="text-2xl">🏠</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">Property Value Estimator</h2>
            <p className="text-slate-600">Run localized prediction models tailored to specific architectural parameters evaluating exact market values in real time. Powered by Python & FastAPI.</p>
          </div>
        </Link>
        
        <Link href="/analysis" className="group">
          <div className="h-full bg-white rounded-2xl shadow-sm border border-slate-200 p-8 hover:shadow-lg transition-all hover:border-emerald-300">
            <div className="h-12 w-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-6">
               <span className="text-2xl">📈</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2 group-hover:text-emerald-600 transition-colors">Market Analysis Dashboard</h2>
            <p className="text-slate-600">Utilize big-data caching pipelines to view large scale systemic visual charts and trigger batch "What-If" matrix testing. Powered by Java & Spring Boot.</p>
          </div>
        </Link>
      </div>

      {stats && (
        <div className="w-full max-w-5xl bg-slate-900 rounded-2xl p-8 text-white text-center mt-12 shadow-2xl">
          <h3 className="text-xl font-medium text-slate-300 mb-6 uppercase tracking-wider">Live Market Averages</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <div>
                <p className="text-slate-400 text-sm">Average Price</p>
                <p className="text-3xl font-bold text-emerald-400">${stats.averagePrice?.toLocaleString()}</p>
             </div>
             <div>
                <p className="text-slate-400 text-sm">Total Properties</p>
                <p className="text-3xl font-bold">{stats.totalListings}</p>
             </div>
             <div>
                <p className="text-slate-400 text-sm">Target Zip Code</p>
                <p className="text-3xl font-bold text-blue-400">{stats.mostPopularZipCode}</p>
             </div>
             <div>
                <p className="text-slate-400 text-sm">Avg Sq Footage</p>
                <p className="text-3xl font-bold">{stats.averageSquareFootage} <span className="text-lg">sqft</span></p>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
